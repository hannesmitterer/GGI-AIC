# GGI-AIC
AIC (artificial intelligence collective) &amp; GGI (global general intelligence) Official Dashboard
registration request to be send: sensisara81@gmail.com